// client/src/App.js
import React, { useState, useEffect } from "react";
import axios from "axios";
import ExpenseForm from "./components/ExpenseForm";
import './index.css'; 


function App() {
  const [expenses, setExpenses] = useState([]);

  // Fetch all expenses from the server on component mount
  useEffect(() => {
    axios.get("http://localhost:5000/api/expense")
      .then(res => setExpenses(res.data))
      .catch(err => console.error(err));
  }, []);

  // Add expense handler
  const handleAddExpense = (expense) => {
    axios.post("http://localhost:5000/api/expense", expense)
      .then(res => setExpenses(prev => [...prev, res.data]))
      .catch(err => console.error(err));
  };

  // Delete expense handler
  const handleDeleteExpense = (id) => {
    axios.delete(`http://localhost:5000/api/expense/${id}`)
      .then(() => setExpenses(prev => prev.filter(e => e._id !== id)))
      .catch(err => console.error(err));
  };

  return (
    <div className="container">
      <h1>Student Expense Tracker</h1>
      <ExpenseForm onAdd={handleAddExpense} />

      <ul>
        {expenses.map((expense) => (
          <li key={expense._id}>
            {expense.title} - ₹{expense.amount} - {expense.category} - {expense.date?.substring(0, 10)}
            <button onClick={() => handleDeleteExpense(expense._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;

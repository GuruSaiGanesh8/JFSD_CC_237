// server/models/Expense.js
import mongoose from "mongoose";

const expenseSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  category: {
    type: String,
    required: true,
    enum: ["Food", "Rent", "Travel", "Books", "Misc"]
  },
  date: {
    type: Date,
    default: Date.now
  }
});

// Use default export here
export default mongoose.model("Expense", expenseSchema);
[]
// server/routes/expenseRoutes.js
import express from 'express';
import {
  createExpense,
  getAllExpenses,
  getExpenseById,
  deleteExpense
} from '../controllers/expenseController.js';

const router = express.Router();

// ✅ POST: Create new expense
router.post('/expense', createExpense);

// ✅ GET: Get all expenses
router.get('/expenses', getAllExpenses);

// (Optional) GET: Get a single expense by ID
router.get('/expense/:id', getExpenseById);

// (Optional) DELETE: Delete an expense
router.delete('/expense/:id', deleteExpense);

export default router;
